
-- Project SQL


-- 1  Get all the details from the person table including email ID, phone number and phone number type

SELECT 
    p.FirstName,
    p.LastName,
    e.EmailAddress AS Email,
    pp.PhoneNumber AS PhoneNumber,
    pnt.Name AS PhoneNumberType
FROM 
    Person.Person AS p
LEFT JOIN 
    Person.EmailAddress AS e ON p.BusinessEntityID = e.BusinessEntityID
LEFT JOIN 
    Person.PersonPhone AS pp ON p.BusinessEntityID = pp.BusinessEntityID
LEFT JOIN 
    Person.PhoneNumberType AS pnt ON pp.PhoneNumberTypeID = pnt.PhoneNumberTypeID


-- 2  Get the details of the sales header order made in May 2011
 

SELECT 
  *
FROM 
    Sales.SalesOrderHeader AS sa
WHERE 
    YEAR(sa.OrderDate) = 2011
    AND MONTH(sa.OrderDate) = 5

-- 3 Get the details of the sales details order made in the month of May 2011


SELECT 
    sod.SalesOrderID,
    sod.SalesOrderDetailID,
    sod.OrderQty,
    sod.UnitPrice,
    sod.LineTotal
FROM 
    Sales.SalesOrderHeader AS soh
JOIN 
    Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID
WHERE 
    YEAR(soh.OrderDate) = 2011
    AND MONTH(soh.OrderDate) = 5

-- 4 Get the total sales made in May 2011

SELECT 
    SUM(sod.LineTotal) AS TotalSales
FROM 
    Sales.SalesOrderHeader AS soh
JOIN 
    Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID
WHERE 
    YEAR(soh.OrderDate) = 2011
    AND MONTH(soh.OrderDate) = 5

-- 5  Get the total sales made in the year 2011 by month order by increasing sales

SELECT 
    MONTH(soh.OrderDate) AS Month,
    YEAR(soh.OrderDate) AS Year,
    SUM(sod.LineTotal) AS TotalSales
FROM 
    Sales.SalesOrderHeader AS soh
JOIN 
    Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID
WHERE 
    YEAR(soh.OrderDate) = 2011
GROUP BY 
    YEAR(soh.OrderDate), MONTH(soh.OrderDate)
ORDER BY 
    Year, Month

-- 6 Get the total sales made to the customer with FirstName='Gustavo' and LastName ='Achong'

SELECT 
    SUM(sod.LineTotal) AS TotalSales
FROM 
    Sales.SalesOrderHeader AS soh
JOIN 
    Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID
JOIN 
    Person.Person AS p ON soh.CustomerID = p.BusinessEntityID
WHERE 
    p.FirstName = 'Gustavo'
    AND p.LastName = 'Achong'



